package Impl;

import Archive.Job;
import Archive.OrderedList;
import java.util.function.Function;

public class DeadlineJob<T extends Comparable<T>> implements Job<T> {
    private Function<T, T> task;
    private int jobId;
    private long creationTimestamp;
    private int relativeDeadline;
    private IdDispatcherImpl idDispatcher;

    public DeadlineJob(Function<T, T> task, int relativeDeadline, IdDispatcherImpl dispatcher) {
        this.task = task;
        this.relativeDeadline = relativeDeadline;
        this.idDispatcher = dispatcher;
        this.jobId = dispatcher.getId();
        this.creationTimestamp = System.currentTimeMillis();
    }

    @Override
    public long getWeight() {
        long weight = getBaseWeight();
        long T = System.currentTimeMillis();
        if (T % 2 == 1) {
            weight += T % 1700;
        } else {
            weight += T / 1000000000;
        }
        weight += relativeDeadline;
        return weight;
    }

    @Override
    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    @Override
    public int getJobId() {
        return jobId;
    }

    @Override
    public T run(T input) {
        System.out.println("Running Deadline Job: " + jobId + " " + getWeight());
        return task.apply(input);
    }

    @Override
    public Function<T, T> getTask() {
        return task;
    }

    @Override
    public OrderedList<Job<T>> getChildJobs() {
        // Deadline jobs have no children.
        return new OrderedListImpl<>((a, b) -> (int)(a.getCreationTimestamp() - b.getCreationTimestamp()));
    }

    @Override
    public int compareTo(Job<T> o) {
        return Long.compare(this.getWeight(), o.getWeight());
    }
}
