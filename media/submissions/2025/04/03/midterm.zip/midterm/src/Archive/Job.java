package Archive;

import java.util.function.Function;

public interface Job<T extends Comparable<T>> extends Comparable<Job<T>> {
    long getWeight();
    long getCreationTimestamp();
    int getJobId();

    // Executes the task(s) associated with this job.
    T run(T input);

    // Returns the owned task. MultiJob returns null.
    Function<T,T> getTask();

    // Returns the child jobs. Non-multijob returns an empty list.
    OrderedList<Job<T>> getChildJobs();

    // Returns an artificial base weight.
    // Do not modify or override!
    default long getBaseWeight() {
        return 1500;
    }
}
