package Archive;

import java.util.function.Function;

public interface JobQueue<T extends Comparable<T>> extends Iterable<Function<T,T>> {
    // Adds `j` to the rear of this job queue.
    void addJob(Job<T> j);

    // Removes and returns the job from the head of this job queue.
    // If there is no job, should return an exception of the `NoJobInTheQueue` type.
    Job<T> getJob();

    // Returns the number of jobs in the queue.
    int size();

    // Removes expired jobs from this queue.
    void purge(long timestamp);
}
