package Archive;

import java.util.function.Predicate;

public interface OrderedList<E> {
  // Add `val` to the ordered list.
  void add(E val);

  // Remove the element at the head.
  void removeHead();

  // Returns the element at the given index.
  E get(int index);

  // Returns the length of the list
  int size();

  // Returns a sublist which contains the elements that satisfy the predicate.
  OrderedList<E> subList(Predicate<E> pred);
}
