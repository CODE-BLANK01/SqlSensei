package Impl;

import Archive.IdDispatcher;

public class IdDispatcherImpl implements IdDispatcher {
    private static int counter = 0;

    @Override
    public int getId() {
        return ++counter;
    }
}
