package Impl;

import Archive.Job;
import Archive.OrderedList;
import java.util.function.Function;

public class PeriodicJob<T extends Comparable<T>> implements Job<T> {
    private Function<T, T> task;
    private int jobId;
    private long creationTimestamp;
    private int period;
    private IdDispatcherImpl idDispatcher;
    private JobQueueImpl<T> jobQueue;  // Reference to the job queue for re-adding the job.

    public PeriodicJob(Function<T, T> task, int period, IdDispatcherImpl dispatcher, JobQueueImpl<T> jobQueue) {
        this.task = task;
        this.period = period;
        this.idDispatcher = dispatcher;
        this.jobQueue = jobQueue;
        this.jobId = dispatcher.getId();
        this.creationTimestamp = System.currentTimeMillis();
    }

    @Override
    public long getWeight() {
        long weight = getBaseWeight();
        long T = System.currentTimeMillis();
        if (T % 2 == 1) {
            weight += T % 1700;
        } else {
            weight += T / 1000000000;
        }
        weight += period * 10;
        return weight;
    }

    @Override
    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    @Override
    public int getJobId() {
        return jobId;
    }

    @Override
    public T run(T input) {
        System.out.println("Running Periodic Job: " + jobId + " " + getWeight());
        T result = task.apply(input);
        // Create a new periodic job instance (with updated timestamp and id) and add it back.
        PeriodicJob<T> newJob = new PeriodicJob<>(task, period, idDispatcher, jobQueue);
        jobQueue.addJob(newJob);
        return result;
    }

    @Override
    public Function<T, T> getTask() {
        return task;
    }

    @Override
    public OrderedList<Job<T>> getChildJobs() {
        // Periodic jobs have no children.
        return new OrderedListImpl<>((a, b) -> (int)(a.getCreationTimestamp() - b.getCreationTimestamp()));
    }

    @Override
    public int compareTo(Job<T> o) {
        return Long.compare(this.getWeight(), o.getWeight());
    }
}
