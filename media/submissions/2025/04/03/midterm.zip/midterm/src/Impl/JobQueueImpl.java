package Impl;

import Archive.Job;
import Archive.JobQueue;
import Archive.OrderedList;
import java.util.Iterator;
import java.util.function.Function;

public class JobQueueImpl<T extends Comparable<T>> implements JobQueue<T> {
    // Internally, maintain jobs in an ordered list (sorted by job weight).
    private OrderedList<Job<T>> jobs;

    public JobQueueImpl() {
        jobs = new OrderedListImpl<>((a, b) -> Long.compare(a.getWeight(), b.getWeight()));
    }

    @Override
    public void addJob(Job<T> j) {
        jobs.add(j);
    }

    @Override
    public Job<T> getJob() {
        if (jobs.size() == 0)
            throw new NoJobInTheQueue("No job in the queue");
        Job<T> head = jobs.get(0);
        jobs.removeHead();
        return head;
    }

    @Override
    public int size() {
        return jobs.size();
    }

    @Override
    public void purge(long timestamp) {
        // Rebuild the job list with only those jobs that are fresh.
        OrderedList<Job<T>> newJobs = new OrderedListImpl<>((a, b) -> Long.compare(a.getWeight(), b.getWeight()));
        for (int i = 0; i < jobs.size(); i++) {
            Job<T> job = jobs.get(i);
            if (job.getCreationTimestamp() >= timestamp) {
                // For multi-jobs, purge any expired child jobs.
                if (job instanceof MultiJob) {
                    ((MultiJob<T>) job).purgeChildJobs(timestamp);
                }
                newJobs.add(job);
            }
        }
        jobs = newJobs;
    }

    @Override
    public Iterator<Function<T, T>> iterator() {
        return new Iterator<Function<T, T>>() {
            private int index = 0;
            @Override
            public boolean hasNext() {
                return index < jobs.size();
            }
            @Override
            public Function<T, T> next() {
                return jobs.get(index++).getTask();
            }
        };
    }
}
