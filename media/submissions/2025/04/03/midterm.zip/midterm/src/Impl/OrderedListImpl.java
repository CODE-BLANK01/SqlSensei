package Impl;

import Archive.OrderedList;
import java.util.function.Predicate;
import java.util.Comparator;

public class OrderedListImpl<E> implements OrderedList<E> {

    private class Node {
        E data;
        Node next;
        Node(E data) { this.data = data; }
    }

    private Node head;
    private int size;
    private Comparator<? super E> comparator;

    // Default constructor using natural ordering.
    public OrderedListImpl() {
        this(null);
    }

    // Constructor with custom comparator.
    public OrderedListImpl(Comparator<? super E> comparator) {
        this.comparator = comparator;
        this.head = null;
        this.size = 0;
    }

    @Override
    public void add(E val) {
        Node newNode = new Node(val);
        if (head == null || compare(val, head.data) <= 0) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && compare(val, current.next.data) > 0) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
        size++;
    }

    // Compare using the comparator if provided; otherwise, use natural ordering.
    @SuppressWarnings("unchecked")
    private int compare(E a, E b) {
        if (comparator != null) {
            return comparator.compare(a, b);
        } else {
            return ((Comparable<E>) a).compareTo(b);
        }
    }

    @Override
    public void removeHead() {
        if (head != null) {
            head = head.next;
            size--;
        }
    }

    @Override
    public E get(int index) {
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds.");
        Node current = head;
        for (int i = 0; i < index; i++)
            current = current.next;
        return current.data;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public OrderedList<E> subList(java.util.function.Predicate<E> pred) {
        OrderedListImpl<E> newList = new OrderedListImpl<>(comparator);
        Node current = head;
        while (current != null) {
            if (pred.test(current.data))
                newList.add(current.data);
            current = current.next;
        }
        return newList;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node current = head;
        while (current != null) {
            sb.append(current.data.toString());
            if (current.next != null)
                sb.append(" ");
            current = current.next;
        }
        return sb.toString();
    }
}
