package Archive;

public interface IdDispatcher {
    // Returns an id (monotonically increasing).
    int getId();
}
