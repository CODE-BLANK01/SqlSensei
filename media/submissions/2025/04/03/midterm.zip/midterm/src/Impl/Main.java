package Impl;//package Impl;

import Archive.Job;
import java.util.function.Function;
import Archive.OrderedList;

public class Main {
    public static void main(String[] args) {
        IdDispatcherImpl dispatcher = new IdDispatcherImpl();
        JobQueueImpl<Integer> queue = new JobQueueImpl<>();

        // Sample task: increment the input by 1.
        Function<Integer, Integer> task = x -> x + 1;

        // Create a periodic job.
        Job<Integer> pJob = new PeriodicJob<>(task, 5, dispatcher, queue);

        // Create a deadline job.
        Job<Integer> dJob1 = new DeadlineJob<>(task, 17, dispatcher);

        // Create a child deadline job.
        Job<Integer> dJob2 = new DeadlineJob<>(task, 23, dispatcher);

        // Build a child job list for a MultiJob (ordered by creation timestamp).
        OrderedList<Job<Integer>> childJobs = new OrderedListImpl<>(
                (a, b) -> (int)(a.getCreationTimestamp() - b.getCreationTimestamp())
        );
        childJobs.add(dJob2);

        // Create a multi-job.
        Job<Integer> mJob = new MultiJob<>(childJobs, dispatcher);

        // Add jobs to the queue.
        queue.addJob(pJob);
        queue.addJob(dJob1);
        queue.addJob(mJob);

        int n = 10;
        int input = 23;
        while (queue.size() > 0 && n-- > 0) {
            Job<Integer> j = queue.getJob();
            System.out.println("Result: " + j.run(input));
            if (n == 5) {
                // Purge jobs created before the current time.
                queue.purge(System.currentTimeMillis());
            }
        }
    }
}
