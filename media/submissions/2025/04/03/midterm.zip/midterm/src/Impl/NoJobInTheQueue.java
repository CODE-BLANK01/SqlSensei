package Impl;

public class NoJobInTheQueue extends RuntimeException {
    public NoJobInTheQueue(String message) {
        super(message);
    }
}
