package Impl;

import Archive.Job;
import Archive.OrderedList;
import java.util.function.Function;

public class MultiJob<T extends Comparable<T>> implements Job<T> {
    // Holds child jobs ordered by creation timestamp.
    private OrderedList<Job<T>> childJobs;
    private int jobId;
    private long creationTimestamp;
    private IdDispatcherImpl idDispatcher;

    public MultiJob(OrderedList<Job<T>> childJobs, IdDispatcherImpl dispatcher) {
        this.childJobs = childJobs;
        this.idDispatcher = dispatcher;
        this.jobId = dispatcher.getId();
        this.creationTimestamp = System.currentTimeMillis();
    }

    @Override
    public long getWeight() {
        long weight = getBaseWeight();
        long T = System.currentTimeMillis();
        if (T % 2 == 1) {
            weight += T % 1700;
        } else {
            weight += T / 1000000000;
        }
        // For MultiJob, job-type-specific weight is the average weight of child jobs divided by 100.
        if (childJobs.size() > 0) {
            long sum = 0;
            for (int i = 0; i < childJobs.size(); i++) {
                sum += childJobs.get(i).getWeight();
            }
            long avg = sum / childJobs.size();
            weight += avg / 100;
        }
        return weight;
    }

    @Override
    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    @Override
    public int getJobId() {
        return jobId;
    }

    @Override
    public T run(T input) {
        System.out.println("Running Multi Job: " + jobId + " " + getWeight());
        T max = null;
        // Execute each child job and determine the maximum result.
        for (int i = 0; i < childJobs.size(); i++) {
            T result = childJobs.get(i).run(input);
            if (max == null || result.compareTo(max) > 0) {
                max = result;
            }
        }
        return max;
    }

    @Override
    public Function<T, T> getTask() {
        // MultiJob does not have an associated task.
        return null;
    }

    @Override
    public OrderedList<Job<T>> getChildJobs() {
        return childJobs;
    }

    @Override
    public int compareTo(Job<T> o) {
        return Long.compare(this.getWeight(), o.getWeight());
    }

    // Helper method for JobQueueImpl.purge: removes expired child jobs.
    public void purgeChildJobs(long timestamp) {
        childJobs = childJobs.subList(job -> job.getCreationTimestamp() >= timestamp);
    }
}
