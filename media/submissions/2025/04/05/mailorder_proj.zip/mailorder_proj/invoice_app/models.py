from django.db import models

class Zipcode(models.Model):
    zip = models.CharField(max_length=6, primary_key=True)
    city = models.CharField(max_length=15)

    def __str__(self):
        return f"{self.zip} - {self.city}"

    class Meta:
        db_table = 'zipcodes'
        managed = False


class Employee(models.Model):
    eno = models.IntegerField(primary_key=True)
    ename = models.CharField(max_length=18)
    zipcode = models.ForeignKey(Zipcode, on_delete=models.PROTECT, db_column='zip')
    hdate = models.DateField()

    def __str__(self):
        return f"{self.eno} - {self.ename}"

    class Meta:
        db_table = 'employees'
        managed = False


class Part(models.Model):
    pno = models.IntegerField(primary_key=True)
    pname = models.CharField(max_length=30)
    qoh = models.IntegerField()
    prices = models.DecimalField(max_digits=5, decimal_places=2)
    wlevel = models.IntegerField()

    def __str__(self):
        return f"{self.pno} - {self.pname}"

    class Meta:
        db_table = 'parts'
        managed = False


class Customer(models.Model):
    cno = models.IntegerField(primary_key=True)
    cname = models.CharField(max_length=18)
    street = models.CharField(max_length=30)
    zipcode = models.ForeignKey(Zipcode, on_delete=models.PROTECT, db_column='zip')
    phone = models.CharField(max_length=15)

    def __str__(self):
        return f"{self.cno} - {self.cname}"

    class Meta:
        db_table = 'customers'
        managed = False


class Order(models.Model):
    ono = models.IntegerField(primary_key=True)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column='cno')
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, db_column='eno')
    received = models.DateField()
    shipped = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"Order {self.ono}"

    class Meta:
        db_table = 'orders'
        managed = False


class OrderDetail(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, db_column='ono', primary_key=True)
    part = models.ForeignKey(Part, on_delete=models.CASCADE, db_column='pno')
    qty = models.IntegerField()

    class Meta:
        db_table = 'odetails'
        managed = False
        constraints = [
            models.UniqueConstraint(fields=['order', 'part'], name='order_part_pk')
        ]

    def __str__(self):
        return f"Order {self.order.ono} - Part {self.part.pno}"
