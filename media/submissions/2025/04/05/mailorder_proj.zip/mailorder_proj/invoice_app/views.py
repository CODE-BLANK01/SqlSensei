from django.shortcuts import render

from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Zipcode, Employee, Part, Customer, Order, OrderDetail


# --- Zipcode Views ---
class ZipcodeListView(ListView):
    model = Zipcode
    template_name = 'invoice_app/zipcode_list.html'

class ZipcodeDetailView(DetailView):
    model = Zipcode
    template_name = 'invoice_app/zipcode_detail.html'

class ZipcodeCreateView(CreateView):
    model = Zipcode
    fields = '__all__'
    template_name = 'invoice_app/zipcode_form.html'
    success_url = reverse_lazy('zipcode_list')

class ZipcodeUpdateView(UpdateView):
    model = Zipcode
    fields = '__all__'
    template_name = 'invoice_app/zipcode_form.html'
    success_url = reverse_lazy('zipcode_list')

class ZipcodeDeleteView(DeleteView):
    model = Zipcode
    template_name = 'invoice_app/zipcode_confirm_delete.html'
    success_url = reverse_lazy('zipcode_list')


# --- Employee Views ---
class EmployeeListView(ListView):
    model = Employee
    template_name = 'invoice_app/employee_list.html'

class EmployeeDetailView(DetailView):
    model = Employee
    template_name = 'invoice_app/employee_detail.html'

class EmployeeCreateView(CreateView):
    model = Employee
    fields = '__all__'
    template_name = 'invoice_app/employee_form.html'
    success_url = reverse_lazy('employee_list')

class EmployeeUpdateView(UpdateView):
    model = Employee
    fields = '__all__'
    template_name = 'invoice_app/employee_form.html'
    success_url = reverse_lazy('employee_list')

class EmployeeDeleteView(DeleteView):
    model = Employee
    template_name = 'invoice_app/employee_confirm_delete.html'
    success_url = reverse_lazy('employee_list')


# --- Part Views ---
class PartListView(ListView):
    model = Part
    template_name = 'invoice_app/part_list.html'

class PartDetailView(DetailView):
    model = Part
    template_name = 'invoice_app/part_detail.html'

class PartCreateView(CreateView):
    model = Part
    fields = '__all__'
    template_name = 'invoice_app/part_form.html'
    success_url = reverse_lazy('part_list')

class PartUpdateView(UpdateView):
    model = Part
    fields = '__all__'
    template_name = 'invoice_app/part_form.html'
    success_url = reverse_lazy('part_list')

class PartDeleteView(DeleteView):
    model = Part
    template_name = 'invoice_app/part_confirm_delete.html'
    success_url = reverse_lazy('part_list')


# --- Customer Views ---
class CustomerListView(ListView):
    model = Customer
    template_name = 'invoice_app/customer_list.html'

class CustomerDetailView(DetailView):
    model = Customer
    template_name = 'invoice_app/customer_detail.html'

class CustomerCreateView(CreateView):
    model = Customer
    fields = '__all__'
    template_name = 'invoice_app/customer_form.html'
    success_url = reverse_lazy('customer_list')

class CustomerUpdateView(UpdateView):
    model = Customer
    fields = '__all__'
    template_name = 'invoice_app/customer_form.html'
    success_url = reverse_lazy('customer_list')

class CustomerDeleteView(DeleteView):
    model = Customer
    template_name = 'invoice_app/customer_confirm_delete.html'
    success_url = reverse_lazy('customer_list')


# --- Order Views ---
class OrderListView(ListView):
    model = Order
    template_name = 'invoice_app/order_list.html'

class OrderDetailView(DetailView):
    model = Order
    template_name = 'invoice_app/order_detail.html'

class OrderCreateView(CreateView):
    model = Order
    fields = '__all__'
    template_name = 'invoice_app/order_form.html'
    success_url = reverse_lazy('order_list')

class OrderUpdateView(UpdateView):
    model = Order
    fields = '__all__'
    template_name = 'invoice_app/order_form.html'
    success_url = reverse_lazy('order_list')

class OrderDeleteView(DeleteView):
    model = Order
    template_name = 'invoice_app/order_confirm_delete.html'
    success_url = reverse_lazy('order_list')


# --- OrderDetail Views ---
class OrderDetailListView(ListView):
    model = OrderDetail
    template_name = 'invoice_app/orderdetail_list.html'

class OrderDetailDetailView(DetailView):
    model = OrderDetail
    template_name = 'invoice_app/orderdetail_detail.html'

class OrderDetailCreateView(CreateView):
    model = OrderDetail
    fields = '__all__'
    template_name = 'invoice_app/orderdetail_form.html'
    success_url = reverse_lazy('orderdetail_list')

class OrderDetailUpdateView(UpdateView):
    model = OrderDetail
    fields = '__all__'
    template_name = 'invoice_app/orderdetail_form.html'
    success_url = reverse_lazy('orderdetail_list')

class OrderDetailDeleteView(DeleteView):
    model = OrderDetail
    template_name = 'invoice_app/orderdetail_confirm_delete.html'
    success_url = reverse_lazy('orderdetail_list')



def invoice_view(request):
    context = {}
    if request.method == 'POST':
        order_number = request.POST.get('order_number')
        if order_number:
            try:
                order_number_int = int(order_number)
                order = Order.objects.get(ono=order_number_int)
                order_details_qs = OrderDetail.objects.filter(order=order).select_related('part')
                
                # Prepare order details with line totals and compute overall total
                total = 0
                details_with_total = []
                for detail in order_details_qs:
                    line_total = detail.qty * detail.part.prices
                    total += line_total
                    details_with_total.append({
                        'part_no': detail.part.pno,
                        'part_name': detail.part.pname,
                        'quantity': detail.qty,
                        'price': detail.part.prices,
                        'line_total': line_total,
                    })
                    
                context.update({
                    'order': order,
                    'order_details': details_with_total,
                    'total': total,
                })
            except (ValueError, Order.DoesNotExist):
                context['error'] = "Order not found or invalid order number."
        else:
            context['error'] = "Please enter an order number."
    return render(request, 'invoice_app/invoice.html', context)