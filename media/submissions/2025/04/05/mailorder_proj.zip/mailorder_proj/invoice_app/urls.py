from django.urls import path
from .views import invoice_view

urlpatterns = [
    path('invoice/', invoice_view, name='invoice'),
    # Additional CRUD view URLs can be added here if needed
]
