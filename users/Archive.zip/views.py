from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, hashers
from django.contrib import messages
from .forms import RegisterForm, LoginForm
from .models import User, Instructor, Student
from courses.models import Course, CourseEnrollment
from assignments.models import Assignment, AssignmentSubmission
from questions.models import Question, AssignmentQuestion, QuestionAttempt
from chat.models import Message
from leaderboard.models import Leaderboard
from django.urls import reverse
from django.utils.timezone import now
from django.http import JsonResponse, HttpResponse
import openai
from django.views.decorators.csrf import csrf_exempt
import json
from django.db.models import Subquery, OuterRef
from django.core.exceptions import ObjectDoesNotExist


def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            return redirect("login")
    else:
        form = RegisterForm()
    return render(request, "users/register.html", {"form": form})


def login_view(request):
    if request.method == "POST":
        form = LoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")

            try:
                user = User.objects.get(username=username)
                if hashers.check_password(password, user.password):
                    request.session["user_id"] = user.user_id
                    request.session["username"] = user.username
                    request.session["role"] = user.role
                    request.session.save()
                    login(request, user)

                    if user.role == "Instructor":
                        return redirect('/users/instructor/dashboard/?show_home=true')
                    elif user.role == "Student":
                        return redirect('/users/student/dashboard/?show_home=true')
                    else:
                        return redirect("welcome")
            except User.DoesNotExist:
                return render(request, "users/login.html", {"form": form, "error": "Invalid credentials"})
    else:
        form = LoginForm()
    return render(request, "users/login.html", {"form": form})


def logout_view(request):
    logout(request)
    return redirect("login")


def welcome_view(request):
    username = request.session.get("username")
    role = request.session.get("role")
    return render(request, "users/welcome.html", {"username": username, "role": role})

# ------------------------------
# Dashboards
# ------------------------------

def instructor_dashboard(request):
    if "user_id" not in request.session:
        return redirect("login")

    user_id = request.session.get("user_id")
    instructor = User.objects.get(user_id=user_id)
    courses = Course.objects.filter(instructor=user_id)
    assignments = Assignment.objects.filter(instructor=user_id)
    questions = Question.objects.filter(instructor=user_id)
    allQuestions = Question.objects.all()
    messages = Message.objects.filter(receiver=request.user).order_by('-message_date')
    users = User.objects.exclude(user_id=user_id)
    pending_enrollments = CourseEnrollment.objects.filter(enrollment_status='Pending')
    query = request.session.get("query", "")
    sql_query = request.session.get("sql_query", "")
    columns = request.session.get("columns", [])
    results = request.session.get("results", [])
    error = request.session.get("error", "")

    request.session.pop("query", None)
    request.session.pop("sql_query", None)
    request.session.pop("columns", None)
    request.session.pop("results", None)
    request.session.pop("error", None)
    assignment_data = []
    for assignment in assignments:
        assignment_questions = AssignmentQuestion.objects.filter(assignment=assignment)
        questionsAssignment = [aq.question for aq in assignment_questions]
        
        assignment_data.append({
            'assignment': assignment,
            'questionsAssignment': questionsAssignment
        })

    return render(request, "users/instructor_dashboard.html", {
        "courses": courses,
        "assignments": assignment_data,
        "questions": questions,
        "allQuestions": allQuestions,
        "pending_enrollments": pending_enrollments,
        "user_name": instructor.full_name,
        "show_manage_courses": True,
        "query": query,
        "sql_query": sql_query,
        "columns": columns,
        "results": results,
        "error": error,
        "users": users,
        "messages": messages,
    })


def student_dashboard(request):
    if "user_id" not in request.session:
        return redirect("login")
    user_id = request.session.get("user_id")
    student = User.objects.get(user_id = user_id)
    #courses = Course.objects.all()
    enrolled_courses = CourseEnrollment.objects.filter(student_id=student).values_list('course_id', flat=True)
    query = request.session.get("query", "")
    sql_query = request.session.get("sql_query", "")
    columns = request.session.get("columns", [])
    results = request.session.get("results", [])
    error = request.session.get("error", "")
    leaderboard_data = request.session.get('leaderboard_data', [])
    approved_course_ids = CourseEnrollment.objects.filter(
    student_id=student,
    enrollment_status='Approved',
    course_id=OuterRef('course_id')
    ).values('course_id')
    approved_courses = Course.objects.filter(course_id__in=Subquery(approved_course_ids))

    request.session.pop("query", None)
    request.session.pop("sql_query", None)
    request.session.pop("columns", None)
    request.session.pop("results", None)
    request.session.pop("error", None)
    request.session.pop("users", None)
    request.session.pop("errmessagesor", None)
    messages = Message.objects.filter(receiver=request.user).order_by('-message_date')
    users = User.objects.exclude(user_id=user_id) 
    # Exclude those courses from the available list
    available_courses = Course.objects.exclude(course_id__in=enrolled_courses).filter(enrollment_status=True)
    return render(request, "users/student_dashboard.html", {
        "courses": available_courses, 
        "user_name": student.full_name,
        "query": query,
        "sql_query": sql_query,
        "columns": columns,
        "results": results,
        "error": error,
        "leaderboard": leaderboard_data,
        "users": users,
        "messages": messages,
        "approved_courses":approved_courses
    })


# ------------------------------
# Course & Assignment ManagementAkshay
# ------------------------------

# def create_course(request):
#     if "user_id" not in request.session:
#         return redirect("login")

#     if request.method == "POST":
#         form = CourseForm(request.POST)
#         if form.is_valid():
#             course = form.save(commit=False)
#             instructor = User.objects.get(user_id=request.session.get("user_id"))
#             course.instructor = instructor
#             course.save()
#             return redirect(reverse("instructor_dashboard") + "?show_manage_courses=true")
#     else:
#         form = CourseForm()

#     return render(request, "users/instructor_dashboard.html", {
#         "form": form,
#         "show_form": True,
#         "show_manage_courses": True
#     })


# def create_assignment(request): Akshay
#     if "user_id" not in request.session:
#         return redirect("login")

#     if request.method == "POST":
#         form = AssignmentForm(request.POST)
#         print(request.POST)  # Debugging: Check form data
#         selected_questions = request.POST.get("questions", "").split(",")  # Get selected question IDs
#         if form.is_valid():
#             assignment = form.save(commit=False)
#             course_id = request.POST.get("course_id")
#             course = get_object_or_404(Course, course_id=course_id)
#             instructor = User.objects.get(user_id=request.session.get("user_id"))
#             assignment.course = course
#             assignment.instructor = instructor
#             assignment.save()
#             print(f"selected_questions: {selected_questions}")  # Print errors if form is invalid
#             # Insert records into Assignment_Questions table
#             for question_id in selected_questions:
#                 if question_id.strip():  # Ensure it's not empty
#                     question = get_object_or_404(Question, question_id=int(question_id))
#                     AssignmentQuestion.objects.create(assignment=assignment, question=question)


#             messages.success(request, "Assignment created successfully.")
#             return redirect(reverse("instructor_dashboard") + "?show_manage_assignments=true")
#     else:
#         form = AssignmentForm()

#     return render(request, "users/instructor_dashboard.html", {
#         "form": form,
#         "show_form": True,
#         "show_manage_courses": True
#     })


# def delete_course(request, course_id): akshay
#     if "user_id" not in request.session:
#         return redirect("login")

#     course = get_object_or_404(Course, course_id=course_id)
#     course.delete()
#     messages.success(request, "Course deleted successfully.")
#     return redirect(reverse("instructor_dashboard") + '?show_manage_courses=true')


# def delete_assignment(request, assignment_id): Akshay
#     if "user_id" not in request.session:
#         return redirect("login")

#     assignment = get_object_or_404(Assignment, assignment_id=assignment_id)
#     assignment.delete()
#     messages.success(request, "Assignment deleted successfully.")
#     return redirect(reverse("instructor_dashboard") + '?show_manage_assignments=true')

# def create_question(request): Akshay
#     if "user_id" not in request.session:
#         return redirect('/login/')

#     if request.method == "POST":
#         form = QuestionForm(request.POST)

#         if form.is_valid():
#             question = form.save(commit=False)
#             user_id = request.session.get("user_id")
#             created_by = User.objects.get(user_id=user_id)
#             question.instructor = created_by  # Assign the creator
#             question.save()
#             messages.success(request, "Question created successfully.")
#             return redirect(reverse("instructor_dashboard") + "?show_manage_questions=true") 
#     else:
#         form = QuestionForm()

#     return render(request, "create_question.html", {"form": form})

# def delete_question(request, question_id): Akshay
#     if "user_id" not in request.session:
#         return redirect('/login/')
#     question = Question.objects.filter(question_id=question_id)
#     question.delete()
#     messages.success(request, "Qurstion deleted successfully.")
#     return redirect(reverse('instructor_dashboard') + '?show_manage_questions=true')


# def approve_student(request, enrollment_id): Akshay
#     if "user_id" not in request.session:
#         return redirect('/login/')
#     enrollment = get_object_or_404(CourseEnrollment, pk=enrollment_id)
#     #if request.user.is_staff:  # Ensuring only instructors can approve
#     enrollment.enrollment_status = 'Approved'
#     enrollment.approval_date = now()
#     enrollment.save()
#     messages.success(request, "Student approved successfully.")
#     return redirect(reverse("instructor_dashboard") + "?show_student_approvals=true")


# def deny_student(request, enrollment_id): Akshay
#     if "user_id" not in request.session:
#         return redirect('/login/')
#     enrollment = get_object_or_404(CourseEnrollment, pk=enrollment_id)
    
#     enrollment.enrollment_status = 'Denied'
#     enrollment.approval_date = now()
#     enrollment.save()
#     messages.error(request, "Student enrollment denied.")
#     return redirect(reverse("instructor_dashboard") + "?show_student_approvals=true")


# def student_approvals(request): Akshay
#     # Your logic here (e.g., fetching pending students for approval)
#     return redirect(reverse("instructor_dashboard") + "?show_student_approvals=true")

def get_assignment_questions(request, assignment_id):
    # Fetch the questions for the given assignment
    assignment_questions = AssignmentQuestion.objects.filter(assignment_id=assignment_id)
    questions = [aq.question.question_title for aq in assignment_questions]
    
    return JsonResponse({'questions': questions})

# def all_questions(request): Akshay
#     if "user_id" not in request.session:
#         return redirect("login")

#     questions = Question.objects.filter(access_type="Public")

#     return render(request, "users/all_questions.html", {"questions": questions})

# client = openai.OpenAI(api_key="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")
# #openai.api_key = "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"

# # def attempt_question(request, question_id): Akshay
# #     if "user_id" not in request.session:
# #         return redirect("login")

# #     question = get_object_or_404(Question, question_id=question_id)
# #     return render(request, "users/attempt_question.html", {"question": question})

# @csrf_exempt
# def evaluate_query(request): Akshay
#     print("Received request at /users/evaluate_query/")  # Debugging step 1
    
#     if request.method == "POST":
#         try:
#             data = json.loads(request.body)
#             print("Request body:", data)  # Debugging step 2
            
#             question_id = data.get("question_id")
#             student_query = data.get("query")

#             if not question_id or not student_query:
#                 print("Error: Missing question_id or query")  # Debugging step 3
#                 return JsonResponse({"error": "Missing question_id or query"}, status=400)

#             # Get the question description
#             question = get_object_or_404(Question, question_id=question_id)
#             print("Retrieved question:", question.description)  # Debugging step 4

#             # Create a prompt for OpenAI
#             prompt = f"""
#             Given the SQL question description:
#             "{question.description}"

#             The student wrote this SQL query:
#             "{student_query}"

#             Provide constructive feedback on the correctness of the query, highlight any errors, and suggest improvements. First word should be correct or incorrect.
#             """

#             print("Generated OpenAI prompt:\n", prompt)  # Debugging step 5

#             # Use OpenAI Client to send the request
#             response = client.chat.completions.create(
#                 model="gpt-4",
#                 messages=[{"role": "user", "content": prompt}]
#             )

#             print("OpenAI response received.")  # Debugging step 6

#             feedback = response.choices[0].message.content
#             attempt_success = feedback.startswith("Correct")
#             print("Extracted feedback:", feedback)  # Debugging step 7

#             # Save attempt in the database
#             user_id = request.session.get("user_id")
#             student = User.objects.get(user_id=user_id)
#             question_attempt = QuestionAttempt.objects.create(
#                 student=student,
#                 question=question,
#                 attempt_date=now(),
#                 attempt_number=1,
#                 student_query=student_query,
#                 feedback=feedback,
#                 attempt_success=attempt_success
#             )

#             return JsonResponse({"feedback": feedback})

#         except json.JSONDecodeError:
#             print("Error: Invalid JSON format")  # Debugging step 8
#             return JsonResponse({"error": "Invalid JSON format"}, status=400)

#         except openai.OpenAIError as e:
#             print(f"OpenAI API Error: {str(e)}")  # Debugging step 9
#             return JsonResponse({"error": f"OpenAI API error: {str(e)}"}, status=500)

#         except Exception as e:
#             print(f"Unexpected error: {str(e)}")  # Debugging step 10
#             return JsonResponse({"error": f"Unexpected error: {str(e)}"}, status=500)

#     print("Error: Invalid request method")  # Debugging step 11
#     return JsonResponse({"error": "Invalid request method"}, status=405)

# def view_leaderboard(request): Akshay
#     if "user_id" not in request.session:
#         return redirect("login")
#     # Fetch the leaderboard data along with the student name from the User table
#     leaderboard_data = Leaderboard.objects.all().order_by('-problems_solved')
    
#     # Enhance the leaderboard data with student names from the User table
#     leaderboard_with_names = []
#     for entry in leaderboard_data:
#         student = User.objects.get(user_id=entry.student_id)  # Assuming 'student_id' in Leaderboard matches 'user_id' in User table
#         leaderboard_with_names.append({
#             "student_name": student.full_name,  # Add student name from User table
#             "problems_solved": entry.problems_solved,
#         })
    
#     # Save the leaderboard data with names to the session
#     request.session['leaderboard_data'] = leaderboard_with_names
    
#     # Redirect to the dashboard with leaderboard data
#     return redirect("/users/student/dashboard/?show_leaderboard=true")


def send_message(request):
    if "user_id" not in request.session:
        return redirect("login")
    user_id = request.session.get("user_id")
    user = User.objects.get(user_id = user_id)
    user_role = user.role.lower()

    if user_role == "student":
        url = "/users/student/dashboard/?show_messages=true"
    elif user_role == "instructor":
        url = "/users/instructor/dashboard/?show_messages=true" 
    if request.method == "POST":
        receiver_id = request.POST.get("receiver_id")
        message_content = request.POST.get("message_content")
        receiver = get_object_or_404(User, pk=receiver_id)
        Message.objects.create(sender=request.user, receiver=receiver, message_content=message_content)
        return redirect(url)
    return redirect(url)


# def view_courses(request): Akshay
#     # Fetch the leaderboard data along with the student name from the User table
#     if "user_id" not in request.session:
#         return redirect("login")
    
#     # Redirect to the dashboard with leaderboard data
#     return redirect("/users/student/dashboard/?show_courses=true")

# def course_dashboard(request, course_id): Akshay
#     assignments = Assignment.objects.filter(course=course_id)
#     assignment_data = []
#     for assignment in assignments:
#         assignment_questions = AssignmentQuestion.objects.filter(assignment=assignment)
#         questionsAssignment = [aq.question for aq in assignment_questions]
#         assignment_data.append({
#             'assignment': assignment,
#             'questionsAssignment': questionsAssignment
#         })
#     return render(request, 'users/course_dashboard.html', {
#     "course_id": course_id,
#     "assignments": assignment_data,})

# def submit_assignment(request, assignment_id): Akshay
#     # Get the current student from request
#     if "user_id" not in request.session:
#         return redirect("login")
#     user_id = request.session.get("user_id")
#     student = User.objects.get(user_id = user_id)
    
#     try:
#         assignment = Assignment.objects.get(pk=assignment_id)
#     except ObjectDoesNotExist:
#         return HttpResponse("Assignment not found", status=404)

#     if request.method == 'POST' and request.FILES.get('zipFile'):
#         zip_file = request.FILES['zipFile']
        
#         # Create an AssignmentSubmission entry
#         submission = AssignmentSubmission(
#             assignment=assignment,
#             student=student,
#             submitted_answer=zip_file,  # Storing the uploaded file
#             submission_status='Pending',  # Status will be Pending initially
#             review_status='Not Graded'  # Set as Not Graded initially
#         )
#         submission.save()
#         file_path = submission.submitted_answer.path
#         print(file_path)
#         course_id = assignment.course.course_id
#         messages.success(request, "Assignment submitted successfully!")

#         return redirect('course_dashboard', course_id=course_id)

#     return HttpResponse("Invalid request", status=400)