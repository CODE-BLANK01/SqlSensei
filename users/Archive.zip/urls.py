# users/urls.py
from django.urls import path, include
from . import views
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("register/", views.register_view, name="register"),
    path("welcome/", views.welcome_view, name="welcome"),

    path("instructor/dashboard/", views.instructor_dashboard, name="instructor_dashboard"),
    path("student/dashboard/", views.student_dashboard, name="student_dashboard"),

    # path("instructor/create-course/", views.create_course, name="create_course"),Akshay
    # path("instructor/create-assignment/", views.create_assignment, name="create_assignment"), Akshay
    # path("instructor/create-question/", views.create_question, name="create_question"), Akshay
    # path("instructor/delete-course/<int:course_id>/", views.delete_course, name="delete_course"), Akshay
    # path("instructor/delete-assignment/<int:assignment_id>/", views.delete_assignment, name="delete_assignment"), Akshay
    path('course-enrollment/', include('courses.urls')),
    # path("instructor/delete-question/<int:question_id>/", views.delete_question, name="delete_question"), Akshay
    # path("instructor/approve-student/<int:enrollment_id>/", views.approve_student, name="approve_student"),Akshay
    # path("instructor/deny-student/<int:enrollment_id>/", views.deny_student, name="deny_student"),Akshay
    # path("instructor/student-approvals/", views.student_approvals, name='student_approvals'), Akshay
    path('instructor/get-questions/<int:assignment_id>/', views.get_assignment_questions, name='get_assignment_questions'),
    # path("student/questions/", views.all_questions, name="all_questions"), Akshay
    # path("student/questions/attempt/<int:question_id>/", views.attempt_question, name="attempt_question"), AKshay
    # path("evaluate_query/", views.evaluate_query, name="evaluate_query"),Akshay
    # path("student/leaderboard/", views.view_leaderboard, name="view_leaderboard"),Akshay
    # path("student/courses/", views.view_courses, name="view_courses"), Akshay
    # path("student/course/<int:course_id>/", views.course_dashboard, name='course_dashboard'), Akshay
    path("student/messages/send/", views.send_message, name="send_message"),
    # path("student/submit-assignment/<int:assignment_id>/", views.submit_assignment, name='submit_assignment'), Akshay
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)